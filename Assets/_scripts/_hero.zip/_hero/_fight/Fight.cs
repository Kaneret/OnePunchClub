﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using UnityEngine;

public class Fight : MonoBehaviour
{
    /// <summary>
    /// вернуть void после тестов
    /// </summary>
    /// <param name="hero"></param>
    /// <param name="opponent"></param>
    /// <returns></returns>
    static void Clash(IFighter hero, IFighter opponent)
    {
        var skillHero = hero.GetSkill();
        var attackH = hero.Attack;
        skillHero.Setup(hero);

        var skillOpponent = opponent.GetSkill();
        var attackO = opponent.Attack;
        skillOpponent.Setup(opponent);

        Damage(hero, attackH, CountingDamageOf(hero), opponent);

        Damage(opponent, attackO, CountingDamageOf(opponent), hero);

        skillHero.Teardown(hero);

        skillOpponent.Teardown(opponent);
    }

    /// <param name="hero"></param>
    /// <param name="opponent"></param>
    /// <param name="winHero">счетчик побед Протагониста</param>
    /// <param name="winBot">счетчик побед Антагониста</param>
    static void Round(IFighter hero, IFighter opponent, int winHero, int winBot)
    {
        while ((hero.HP.Quanity > 0) &&
            (opponent.HP.Quanity > 0) &&
            (hero.EP.Quanity > 0) &&
            (opponent.EP.Quanity > 0))
        {
            /*var skillsUsed =*/
            Clash(hero, opponent);///убрать массив после тестов
            //DescriptionOfClash(hero, opponent, skillsUsed);///
        }

        //EndOfRound(hero, opponent, winHero, winBot);
    }

    public static void Сombat(IFighter hero, IFighter opponent)
    {
        ///счетчики побед         
        int winHero = 0;
        int winBot = 0;

        for (int i = 0; i < 12; i++)
        {
            SetMaximumFightersHP(hero, opponent);
            //BeginOfRound(i + 1);
            Round(hero, opponent, winHero, winBot);
        }
        //EndOfCombat(winHero, winBot);
        SetMaximumFightersHP(hero, opponent);
    }

    /// <summary>
    /// только для прототипа
    /// </summary>
    /// <param name="hero"></param>
    /// <param name="opponent"></param>
    //static void DescriptionOfClash(MainHero hero, FightBot opponent, ISkill[] skillsUsed)
    //{
    //    Console.WriteLine("========================================================\n" +
    //                      "Протагонист: здоровье = {0}\n" +
    //                      "Используемый навык: {1}",
    //                      hero.HP.Quanity,
    //                      skillsUsed[0].Name);
    //    Console.WriteLine("--------------------------------------------------------\n" +
    //                      "Антагонист: здоровье = {0}\n" +
    //                      "Используемый навык: {1}",
    //                      opponent.HP.Quanity,
    //                      skillsUsed[1].Name);
    //}

    /// <summary>
    /// только для прототипа
    /// </summary>
    /// <param name="number"></param>
    //static void BeginOfRound(int number)
    //{
    //    Console.WriteLine("\n\nРаунд {0}.\n", number);
    //}

    /// <summary>
    /// только для прототипа
    /// </summary>
    /// <param name="hero"></param>
    /// <param name="opponent"></param>
    /// <param name="winHero">счетчик побед Протагониста</param>
    /// <param name="winBot">счетчик побед Антагониста</param>
    //static void EndOfRound(MainHero hero, FightBot opponent, int winHero, int winBot)
    //{
    //    Console.WriteLine("========================================================\n" +
    //            "Раунд окончен. {0}\n" +
    //            "Для продолжения нажмите любую клавишу.",
    //            GetWinnerOfRound(hero, opponent, winHero, winBot));
    //    Console.ReadKey();
    //}

    /// <summary>
    /// только для прототипа
    /// </summary>
    /// <param name="hero"></param>
    /// <param name="opponent"></param>
    /// <param name="winHero">счетчик побед Протагониста</param>
    /// <param name="winBot">счетчик побед Антагониста</param>
    /// <returns></returns>
    //static string GetWinnerOfRound(MainHero hero, FightBot opponent, int winHero, int winBot)
    //{
    //    if (hero.HP.GetQuanity() > opponent.HP.GetQuanity())
    //    {
    //        winHero++; return "Победил Протагонист.";
    //    }
    //    else if (hero.HP.GetQuanity() < opponent.HP.GetQuanity())
    //    {
    //        winBot++; return "Победил Антагонист.";
    //    }
    //    else return "Ничья.";
    //}

    /// <summary>
    /// только для прототипа
    /// </summary>
    /// <param name="winHero">счетчик побед Протагониста</param>
    /// <param name="winBot">счетчик побед Антагониста</param>
    //static void EndOfCombat(int winHero, int winBot)
    //{
    //    if (winHero > winBot)
    //        Console.WriteLine("Победитель боя - Протагонист!");
    //    else if (winHero < winBot)
    //        Console.WriteLine("Победитель боя - Антагонист!");
    //    else if (winHero == winBot)
    //        Console.WriteLine("В бою победителя нет! Ничья по очкам!");
    //    else Console.WriteLine("Ошибка!");
    //    Console.WriteLine("Для продолжения нажмите любую клавишу.");
    //    Console.ReadKey();
    //}

    static void SetMaximumFightersHP(IFighter hero, IFighter opponent)
    {
        hero.HP.SetQuanityMaximum();
        opponent.HP.SetQuanityMaximum();
    }

    static int CountingDamageOf(IFighter fighter)
    {
        return fighter.Attack + fighter.Power.Value * 2;
    }

    static void Damage(IFighter fighter, int attack, int damage, IFighter opponent)
    {
        if (fighter.Attack == attack)
        {
            fighter.EP.DecreaseQuanity(1);
        }
        else
        {
            fighter.EP.DecreaseQuanity(2);
        }

        if (fighter.EP.Quanity == 0)
        {
            damage /= 2;
        }
        opponent.Damage(damage);
    }
}

