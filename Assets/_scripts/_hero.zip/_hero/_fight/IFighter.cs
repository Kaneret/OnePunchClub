﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;


public interface IFighter
{
    int Block { get; set; }
    int Evasion { get; set; }
    int Attack { get; set; }

    Characteristic Dexterity { get; set; }
    Characteristic Power { get; set; }
    Characteristic Stamina { get; set; }

    Parameter EP { get; set; }
    Parameter HP { get; set; }

    ISkill GetSkill();
    void Damage(int damage);
}

