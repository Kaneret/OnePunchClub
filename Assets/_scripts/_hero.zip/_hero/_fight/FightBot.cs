﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class FightBot : MonoBehaviour, IFighter
{
    public Parameter HP { get; set; }
    public Parameter EP { get; set; }
    public int Armor { get; set; }

    public int Block { get; set; }
    public int Evasion { get; set; }
    public int Attack { get; set; }

    public List<ISkill> ActiveFightSkills { get; set; }
    public int MaxQuanityAFS { get; set; }

    public Characteristic Dexterity { get; set; }
    public Characteristic Power { get; set; }
    public Characteristic Stamina { get; set; }

    //private UnityEngine.Random Rnd { get { return new UnityEngine.Random(); } }

    public FightBot()
    {
        HP = new Parameter(20);
        EP = new Parameter(20);

        ActiveFightSkills = new List<ISkill>();
        MaxQuanityAFS = 2;
        Armor = 3;

        Dexterity = new Characteristic(1);
        Power = new Characteristic(1);
        Stamina = new Characteristic(1);

        Block = 1;
        Evasion = 1;
        Attack = 1;
    }

    public ISkill GetSkill()
    {
        var max = ActiveFightSkills.Count;
        ///
        var chance = UnityEngine.Random.Range(0, max * 50);
        var first = chance % max;
        ///
        ///
        var randomFloat = UnityEngine.Random.value;
        var second = max - 1;
        for (int i = 0; i < max; ++i)
        {
            if ((randomFloat >= (i - 1) / max) && (randomFloat < i / max))
            {
                second = i - 1;
            }
        }
        ///
        ///
        var time = DateTime.Now.Second;
        var randomInt = UnityEngine.Random.Range(time + 1, time + 60);
        var timeRand = time / randomInt;
        var third = max - 1;
        for (int i = 0; i < max; ++i)
        {
            if ((timeRand >= (i - 1) / max) && (timeRand < i / max))
            {
                third = i - 1;
            }
        }
        ///
        return ActiveFightSkills[(int)((first + second + third) / 3)];
    }

    public void Damage(int damage)
    {
        if (UnityEngine.Random.value > (Evasion + Dexterity.Value) / 40)
        {
            var dam = damage - (Block + Stamina.Value + Armor);
            if (dam < 0)
            {
                dam = 0;
            }
            HP.DecreaseQuanity(dam);
        }
    }
}

