﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;


public class Characteristic
{
    public Characteristic(int Value)
    {
        this.Value = Value;
        Bar = new Parameter(100, 0);
    }

    public int Value { get; set; }

    /// <summary>
    /// шкала развития характеристики
    /// </summary>
    public Parameter Bar;

    //public void IncreaseValue(int kol)
    //{
    //    if (kol >= 0) Value += kol;
    //    if ((kol < 0) && ((Value + 1) < (-kol))) Value = 1;
    //    else if
    //}
}

