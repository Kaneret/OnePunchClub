﻿using System;


class Program
{
    static void Main(string[] args)
    {
        var hero = new MainHero();
        var opponent = new FightBot();
        
        hero.ActiveFightSkills.Add(new CommonPunch());
        hero.ActiveFightSkills.Add(new CommonBlock());

        opponent.ActiveFightSkills.Add(new CommonPunch());
        opponent.ActiveFightSkills.Add(new CommonEvasion());

        Fight.Сombat(hero, opponent);
    }
}

